#Criar um numero real e mostrar apenas a parte inteira dele, exemplo: 6.127

import math
num=float(input('Digite numero: '))
arre=math.floor(num)
print(arre)
