public class OutraAula {
    public static void main(String[] args) {
        int i = 2;
        if (i == 2) {
            int a = 3;
            if (a == 3){
                int b = 4;
            }
        }
        System.out.println(i + a);
    }
}