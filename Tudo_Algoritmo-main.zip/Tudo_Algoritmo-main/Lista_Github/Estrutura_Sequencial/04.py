pi = 3.14159
raio = float(input('Me fale seu raio: '))

area = 2*raio*pi
print(area)