def somar(a, b):
    return a + b

num= int(input('Digite: '))
num1 = int(input('Digite: '))
resultado = somar(num,num1)
print(resultado)
