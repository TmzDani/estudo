num1=int(input('Digite numero: '))
num2=float(input('Digite numero: '))
print(num1+num2)
