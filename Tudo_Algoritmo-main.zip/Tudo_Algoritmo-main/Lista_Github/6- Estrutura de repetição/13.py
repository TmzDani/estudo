graos = 1
total = 0

for casa in range(1, 65):
    total += graos
    graos *= 2

print(f"O total de grãos é: {total}")