"""
Ao observar a sequência de números abaixo, descubra qual das opções completa a série.

50, 5, 40, 10, 30, ??

35
20
25
15
37
"""

#Resposta: 15, visto que ele segue um padrão intercalado, primeiro ele subtrai 10, depois soma +5, e assim por diante
#logo, o próximo número da sequência é 15.
