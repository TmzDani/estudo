V = [6, 5, 3, 1, 8, 7, 2, 4]

V.sort(reverse=True)
print(V)


tem_cartao = True
saldo_suficiente = False

if tem_cartao or saldo_suficiente:
    print('qualquer coisa')
else:
    print('Fodase')

nome = (input('Digite'))
print(nome)
