n1 = float(input('Fale sua primeira nota: '))
n2 = float(input('Fale sua segunda nota: '))
n3 = float(input('Fale sua terceira nota: '))

mediafinal = (n1*2 + n2*3 + n3*5)/10
print(mediafinal)