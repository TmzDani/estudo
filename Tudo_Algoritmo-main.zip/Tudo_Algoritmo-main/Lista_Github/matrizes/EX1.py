"""EXERCICIOS MATRIZES"""

#Faça uma matriz 2 por 4
matriz =[
    [3,4,6,7],
    [5,4,7,9]
]
print(matriz)

"""Realiza 4 operações em matrizes, a soma da 1 coluna, soma da matriz inteira, 
produto dos elementos da primeira linha e o produto dos elementos da diagonal principal"""
matriz=[
    [1,2,3,4],
    [5,6,7,8],
    [9,10,11,12],
    [13,14,15,16]
]
#Soma a primeira coluna
soma = 0
for linha in matriz:
    soma+= linha[0]
print(soma)

#Produto dos elementos da primeira linha:
produto = 1
for coluna in matriz[0]:
    produto *= coluna
print(produto)

#Soma os todos os elementos
somaT = 0
for todos in matriz:
    for elemento in todos:
        somaT += elemento
print(somaT)

# Produto dos elementos da diagonal principal
produtoD = 1
for diagonal in range(len(matriz)) :
    produtoD *= matriz[diagonal][diagonal]
print(produtoD)