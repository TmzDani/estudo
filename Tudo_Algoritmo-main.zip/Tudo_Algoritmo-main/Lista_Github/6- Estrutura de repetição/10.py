anacleto = 1.50
felisberto = 1.10
anos = 0

while felisberto <= anacleto:
    anacleto += 0.02
    felisberto += 0.03
    anos += 1

print(f"Serão necessários {anos} anos para que Felisberto seja maior que Anacleto.")