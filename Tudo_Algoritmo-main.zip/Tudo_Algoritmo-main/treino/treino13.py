#Desafio guanabara sabendo que por dia o carro alugado custa 60 reais e por km rodado é 0.15

dia = int(input('Digite Dias: '))
km = float(input('Digite Kms: '))
aluguel = dia*60
rodad = km*0.15
total = aluguel + rodad

print(total)

