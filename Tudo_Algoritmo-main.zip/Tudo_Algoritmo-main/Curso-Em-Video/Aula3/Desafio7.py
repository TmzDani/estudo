#Media aritmetica de dois valores

num1=int(input('Digite nota: '))
num2=int(input('Digite nota: '))
media=(num1+num2)/2
print(media)
