"""
. Em uma sala há duas lousas (quadros negros), a lousa A e a lousa B. Na lousa A foi escrito o número 7 e na lousa B 
foi escrito o número 13. Após isso, um aluno entrou na sala, apagou o número da lousa B e em seu lugar 
escreveu um número igual ao número escrito na lousa A. Depois disso, outro aluno entrou na sala, apagou o número da 
lousa A e em seu lugar escreveu um número igual ao número atualmente escrito na lousa B. Depois dessas mudanças, 
quais são os números escritos nas lousas?
13 na lousa A e 7 na lousa B
7 na lousa A e 13 na lousa B
7 na lousa A e 7 na lousa B
13 na lousa A e 13 na lousa B
20 na lousa A e 6 na lousa B
lousa A foi escrito o número 7 e na lousa B foi escrito o número 13.
apagou o número da lousa B e em seu lugar escreveu um número igual(7) ao número escrito na lousa A(7).
apagou o número da lousa A e em seu lugar escreveu um número igual ao número atualmente escrito na lousa B(7).

"""

#Resposta: 7 na lousa A e B
