#Crie um script que peca 2 numeros e mostre a soma entre eles
number1=int(input('Digite numero: '))
number2=int(input('Digite outro numero: '))
print(number1+number2)
