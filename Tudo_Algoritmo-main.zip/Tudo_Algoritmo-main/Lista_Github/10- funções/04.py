#Aqui verifia se o ano é bissexto ou não

ano = int(input('informe o ano: '))
def bi(ano):
    if (ano % 4 == 0 and ano % 100 != 0) or ano % 400 == 0:
        return True
    else:
        return False
print(bi(ano))