x = float(input('N 1: '))
y = float(input('N 2: '))
if x > y:
    print(x)
elif y == x:
    print('Não pode ser igual')
else:
    print(y)