#Crie um script Python que leia o nome da pessoa
#e mostre uma mensagem de boas vindas de acordo com o valor digitado#

nome=input('Digite nome:  ')
print('Boas vindas senhor/a',nome)