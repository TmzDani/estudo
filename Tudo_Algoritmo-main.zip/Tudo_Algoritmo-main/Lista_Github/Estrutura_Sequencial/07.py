temp = float(input('Fale a temperatura para celsius: '))
F = (temp*9/5)+32
print("Celsius: ", temp, " ", "Fahrenheit", F)