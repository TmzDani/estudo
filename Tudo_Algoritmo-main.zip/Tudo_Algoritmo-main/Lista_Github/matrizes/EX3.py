#MatrizA e MatrizB
matrizA = [
    [-10, 1, 4, 6],
    [2, 3, 2, 8]
]
matrizB = [
    [1, 8, 4, -1],
    [0, 6, 3, -3]
]
#Array vazio
soma = []

#Vai percorrer a matrizA inteira
for i in range(len(matrizA)):
    linha_soma = []  
    #Vai pecorrer apenas a 1 linha da matrizA
    for j in range(len(matrizA[i])):
        #Vai realizar um append na soma das primeiras 2 linhas de cada uma
        linha_soma.append(matrizA[i][j] + matrizB[i][j])  
    soma.append(linha_soma) 

for linha in soma:
    print(soma)

