base = int(input("Escolha a base: "))
exp = int(input("Escolha o expoente: "))

calc = base ** exp
print(calc)