"""
Para comemorar o aniversário de Cláudio, ele e mais quatro amigos – Alberto, Beto, Dino e Eurico – foram almoçar 
juntos no restaurante da escola. As mesas são redondas e acomodam exatamente cinco pessoas. Cláudio e Dino sentam-se um 
ao lado do outro. 
Alberto e Beto não sentam-se um ao lado do outro. Os dois amigos sentados ao lado de Eurico são:
"""
"""
- Alberto e Beto
- Cláudio e Dino
- Dino e Beto
- Cláudio e Alberto
- Alberto e Dino
"""

#Resposta: Cláudio e Dino