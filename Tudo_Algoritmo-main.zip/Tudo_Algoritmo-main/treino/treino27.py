def calcular_dobro(a):
    dobro = a * 2
    return dobro

print(calcular_dobro(5))

def temperatura(a):
    temp = 5 / 9 * (a - 32)
    return temp

val = int(input('Digite a temperatura em fahrenin: '))
print(temperatura(val))


