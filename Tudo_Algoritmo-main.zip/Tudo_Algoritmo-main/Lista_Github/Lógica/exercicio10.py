"""
Lúcia foi ao mesmo tempo a décima terceira melhor classificada e a décima terceira pior classificada de um concurso. 
Quantos eram os concorrentes?
"""
#Resposta: podemos concluir que são 12 concorrentes nas duas classificações, 12(acima de lucia), 12(abaixo de lucia)
#e como a lucia também é uma participante, é um total de:
concorrentes = 12 + 12 + 1
print(concorrentes)

