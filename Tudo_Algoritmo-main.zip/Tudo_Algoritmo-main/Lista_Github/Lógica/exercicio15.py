"""
Há cinco casas diferentes em cinco cores diferentes em uma fileira. 
Em cada casa mora uma pessoa com uma diferente nacionalidade. Os cinco proprietários bebem um certo tipo de bebida, 
fuma cigarro de uma certa marca e tem um certo tipo de animal de estimação. Nenhum dos proprietários tem o mesmo 
tipo de animal ou de marca de cigarro ou de bebida. Quem é o dono do peixe? 

O britânico mora na casa vermelha
O suíço tem um cão como animal de estimação
O dinamarquês bebe chá
A casa verde fica imediatamente à esquerda da casa branca
O dono da casa verde bebe café
O proprietário que fuma Pall Mall tem um pássaro
O dono da casa amarela fuma Dunhill
O proprietário morando na casa do centro bebe leite
O norueguês mora na primeira casa
O dono que fuma Blends mora ao lado do que cria gatos
O proprietário que cria um cavalo mora ao lado do que fuma Dunhill
O dono que fuma Bluemasters bebe cerveja
O alemão fuma Prince
O norueguês mora ao lado da casa azul
O proprietário que fuma Blends mora ao lado do que bebe água
"""

#Resposta: O alemão, na casa 4, é o dono do peixe.