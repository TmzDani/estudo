#Sucessor e antecessor do numerio indicado

num=int(input('Digite numero: '))
suce=num+1
ante=num-1
print('Seu sucessor é {} e seu antecessor é {}'.format(suce,ante))
