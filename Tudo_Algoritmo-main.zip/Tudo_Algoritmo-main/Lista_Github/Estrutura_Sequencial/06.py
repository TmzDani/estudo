nome = str(input("Fale seu nome: "))
snome = str(input("Fale seu sobrenome: "))

nomec = nome + " " + snome
print(nomec)