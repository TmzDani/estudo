def soma(a, b):
    a + b
    return a + b

a = 5
b = 6
print(soma(5, 6))