#Matriz identidade é a matriz quadrdad de ordem N(2x2, 3x3, 4x4 ...)
#em que os elementos da diagonal principal são iguais a 1 e, o restante dos elementos
#são iguais a 0, Faça um programaa que peça ao usuario informar o tamanho do ordem e gere a matriz identidade

ordem = int(input('Digite o tamanho: '))


    