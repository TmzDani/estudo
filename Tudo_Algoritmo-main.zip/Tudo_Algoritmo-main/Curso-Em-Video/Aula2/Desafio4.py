num=input('Digite numero: ')
print(num.isnumeric())
print(num.isalpha()) # letra
print(num.isdecimal())
print(num.islower())
print(num.isprintable()) #se pode ser impresso
print(num.isalnum()) # mistura de numero e letra
print(num.isspace()) # se tem espaco
print(num.isascii())
