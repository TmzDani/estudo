comp = float(input("Comprimento: "))
lar = float(input("Largura: "))
alt = float(input("Altura: "))

vol = comp * lar * alt
print(vol)