#Salario informado e sendo adicionado 15%

sal=float(input('Digite valor: '))
novo=sal*0.15
aumento=novo+sal
print(aumento)
