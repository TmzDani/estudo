#Conversor de real para dolar valendo US$3,27

real=float(input('Digite valor: '))
dola=round(real/3.27,2)
print(dola)
