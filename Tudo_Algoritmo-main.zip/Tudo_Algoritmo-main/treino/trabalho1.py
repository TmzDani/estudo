apresentacao = ['Histórico', 'Paradigma','Tipos', 'Definicao',
 'IDE','Curisosidade']
for temas in apresentacao:
    print(temas)


