#Selecione o item do meio do vetor

vet = [6, 3, 5, 3, 4, 0, 10]
ini = 0
meio = len(vet) // 2

item = vet[meio]

print(item)
