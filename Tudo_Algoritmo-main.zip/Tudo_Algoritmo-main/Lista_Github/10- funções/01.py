#Verifica se a primeira palavra será o inicio da segunda
def verifica_prefixo(palavra1, palavra2):
    return palavra2.startswith(palavra1)

palavra1 = input("Digite a primeira palavra: ")     #Pro
palavra2 = input("Digite a segunda palavra: ")      #Programa

resultado = verifica_prefixo(palavra1, palavra2)
print(resultado)                                    #Retorna True, pq Pro começa em Programa

