"""Aqui verifica se o numero digitado é primo ou não, fazendo um cálculo lógico, se o cont chegar a dois, significa que o número
#é primo, se passar, ele não é primo"""

n = int(input('digite um número: '))
def primo(n):
    if n <= 1:
        return False  
    cont = 0
    for i in range(1, n + 1): 
        if n % i == 0:
            cont += 1
    if cont == 2: 
        return True
    else:
        return False
print(primo(n))
