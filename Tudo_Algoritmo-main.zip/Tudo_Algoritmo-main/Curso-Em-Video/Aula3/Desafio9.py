#TABUADA NIVEL INICIANTE

num=int(input('Digite valor: '))
print('Tabuada: {} x {} = {}'.format(num,1,num))
print('Tabuada: {} x {} = {}'.format(num,2,num*2))
print('Tabuada: {} x {} = {}'.format(num,3,num*3))
print('Tabuada: {} x {} = {}'.format(num,4,num*4))
print('Tabuada: {} x {} = {}'.format(num,5,num*5))
print('Tabuada: {} x {} = {}'.format(num,6,num*6))
print('Tabuada: {} x {} = {}'.format(num,7,num*7))
print('Tabuada: {} x {} = {}'.format(num,8,num*8))
print('Tabuada: {} x {} = {}'.format(num,9,num*9))
print('Tabuada: {} x {} = {}'.format(num,10,num*10))
