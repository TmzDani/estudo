#Soma todos os itens dentro do vetor

vet = [5, 3, 10, 9, 4]

soma = 0

for c in vet:
    soma += c
print(soma)
