#Valor informado e transformado em centimetros e milimetros

metro=float(input('Digite um valor: '))
cem=metro*100
mili=metro*1000
print('O valor em centimeros {} e o valor em milimetros {}'.format(cem,mili))
