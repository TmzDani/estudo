maca = int(input('escolha a maça: '))
if maca < 12:
    val = maca * 1.30
elif maca == 12:
    val = maca * 1.10
print(val)

