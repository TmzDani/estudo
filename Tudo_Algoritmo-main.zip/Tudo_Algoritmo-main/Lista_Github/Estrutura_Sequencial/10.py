id = int(input("Me fale sua idade: "))
ms = int(input("Me fale seus meses: "))
ds = int(input("Me fale seus dias: "))

cid = id * 365
cms = ms * 30

id_com = cid + cms + ds
print(id_com)