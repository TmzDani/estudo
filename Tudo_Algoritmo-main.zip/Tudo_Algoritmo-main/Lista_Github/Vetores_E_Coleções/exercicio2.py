"""
Faça um programa que copie o conteúdo de um vetor em um segundo vetor.
"""

vet = [1, 2, 56, 92, 100]
aux = []

for c in vet:
    aux.append(c)

print(vet)
print(aux)

