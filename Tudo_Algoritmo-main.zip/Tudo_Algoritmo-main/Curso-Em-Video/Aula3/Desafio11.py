#Altura e largura e a definicao de quantidade de litros serao necessarios para pintar

alt=float(input('Digite valor: '))
lar=float(input('Digite valor: '))
peri=alt*lar
quant=peri/2
print(quant)
